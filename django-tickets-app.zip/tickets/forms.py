from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Solicitud, UserProfile, Comentario

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=UserProfile.ROLES, required=True)
    
    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
            UserProfile.objects.create(
                user=user,
                role=self.cleaned_data["role"]
            )
        return user

class SolicitudForm(forms.ModelForm):
    class Meta:
        model = Solicitud
        fields = [
            'tipo_solicitud', 'tipo_archivo', 'archivo_adjunto', 
            'descripcion', 'url_commit', 'nombre_branch', 'entorno'
        ]
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 4}),
            'tipo_solicitud': forms.Select(attrs={'class': 'form-control'}),
            'tipo_archivo': forms.Select(attrs={'class': 'form-control'}),
            'archivo_adjunto': forms.FileInput(attrs={'class': 'form-control'}),
            'url_commit': forms.URLInput(attrs={'class': 'form-control'}),
            'nombre_branch': forms.TextInput(attrs={'class': 'form-control'}),
            'entorno': forms.TextInput(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Hacer campos condicionales según el tipo de solicitud
        self.fields['url_commit'].required = False
        self.fields['nombre_branch'].required = False
        self.fields['entorno'].required = False

class ComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ['texto']
        widgets = {
            'texto': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        }

class CambiarEstadoForm(forms.Form):
    ESTADOS = Solicitud.ESTADOS
    
    nuevo_estado = forms.ChoiceField(choices=ESTADOS, widget=forms.Select(attrs={'class': 'form-control'}))
    comentario = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        required=False
    )
