from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Autenticación
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.register, name='register'),
    
    # Dashboard y solicitudes
    path('', views.dashboard, name='dashboard'),
    path('crear/', views.crear_solicitud, name='crear_solicitud'),
    path('solicitud/<int:pk>/', views.detalle_solicitud, name='detalle_solicitud'),
    path('solicitud/<int:pk>/descargar-sql/', views.descargar_script_sql, name='descargar_script_sql'),
    
    # Estadísticas (solo admin)
    path('estadisticas/', views.estadisticas, name='estadisticas'),
]
