import pandas as pd
import openpyxl
from django.core.files.storage import default_storage
import os

def procesar_archivo_excel(solicitud):
    """
    Procesa archivos Excel según el tipo de solicitud y genera scripts SQL
    """
    if not solicitud.archivo_adjunto:
        return None
    
    try:
        # Leer el archivo Excel
        file_path = solicitud.archivo_adjunto.path
        df = pd.read_excel(file_path)
        
        if solicitud.tipo_solicitud in ['crear_tabla', 'modificar_tabla']:
            return generar_script_tabla(df, solicitud.tipo_solicitud)
        elif solicitud.tipo_solicitud in ['asignar_permisos', 'crear_usuarios']:
            return generar_script_permisos_usuarios(df, solicitud.tipo_solicitud)
        
    except Exception as e:
        print(f"Error procesando archivo Excel: {e}")
        return None
    
    return None

def generar_script_tabla(df, tipo_solicitud):
    """
    Genera script SQL para creación o modificación de tablas
    """
    try:
        # Validar que el DataFrame tenga las columnas necesarias
        columnas_requeridas = ['nombre_columna', 'tipo_dato', 'nullable', 'clave_primaria']
        if not all(col in df.columns for col in columnas_requeridas):
            return "-- Error: El archivo Excel debe contener las columnas: nombre_columna, tipo_dato, nullable, clave_primaria"
        
        # Obtener nombre de tabla (puede estar en una celda específica o ser parametrizable)
        nombre_tabla = df.iloc[0].get('nombre_tabla', 'nueva_tabla')
        
        if tipo_solicitud == 'crear_tabla':
            script = f"-- Script generado automáticamente para creación de tabla\n"
            script += f"CREATE TABLE {nombre_tabla} (\n"
            
            columnas = []
            for _, row in df.iterrows():
                if pd.isna(row['nombre_columna']):
                    continue
                    
                nombre_col = row['nombre_columna']
                tipo_dato = row['tipo_dato']
                nullable = "NOT NULL" if str(row['nullable']).lower() == 'no' else ""
                pk = "PRIMARY KEY" if str(row['clave_primaria']).lower() == 'si' else ""
                
                columna_def = f"    {nombre_col} {tipo_dato} {nullable} {pk}".strip()
                columnas.append(columna_def)
            
            script += ",\n".join(columnas)
            script += "\n);"
            
        else:  # modificar_tabla
            script = f"-- Script generado automáticamente para modificación de tabla\n"
            for _, row in df.iterrows():
                if pd.isna(row['nombre_columna']):
                    continue
                    
                nombre_col = row['nombre_columna']
                tipo_dato = row['tipo_dato']
                accion = row.get('accion', 'ADD')  # ADD, DROP, MODIFY
                
                if accion.upper() == 'ADD':
                    script += f"ALTER TABLE {nombre_tabla} ADD COLUMN {nombre_col} {tipo_dato};\n"
                elif accion.upper() == 'DROP':
                    script += f"ALTER TABLE {nombre_tabla} DROP COLUMN {nombre_col};\n"
                elif accion.upper() == 'MODIFY':
                    script += f"ALTER TABLE {nombre_tabla} MODIFY COLUMN {nombre_col} {tipo_dato};\n"
        
        return script
        
    except Exception as e:
        return f"-- Error generando script de tabla: {str(e)}"

def generar_script_permisos_usuarios(df, tipo_solicitud):
    """
    Genera script SQL para permisos y usuarios
    """
    try:
        if tipo_solicitud == 'crear_usuarios':
            script = "-- Script generado automáticamente para creación de usuarios\n"
            
            for _, row in df.iterrows():
                if pd.isna(row.get('nombre_usuario')):
                    continue
                    
                usuario = row['nombre_usuario']
                password = row.get('password', 'temp_password')
                rol = row.get('rol', 'user_role')
                
                script += f"CREATE USER '{usuario}'@'%' IDENTIFIED BY '{password}';\n"
                script += f"GRANT {rol} TO '{usuario}'@'%';\n"
                script += f"FLUSH PRIVILEGES;\n\n"
                
        else:  # asignar_permisos
            script = "-- Script generado automáticamente para asignación de permisos\n"
            
            for _, row in df.iterrows():
                if pd.isna(row.get('usuario')):
                    continue
                    
                usuario = row['usuario']
                tabla = row.get('tabla', '*')
                permisos = row.get('permisos', 'SELECT')
                
                script += f"GRANT {permisos} ON {tabla} TO '{usuario}'@'%';\n"
            
            script += "FLUSH PRIVILEGES;\n"
        
        return script
        
    except Exception as e:
        return f"-- Error generando script de permisos/usuarios: {str(e)}"

def validar_estructura_excel(df, tipo_solicitud):
    """
    Valida que la estructura del Excel cumpla con los criterios
    """
    validaciones = {
        'crear_tabla': ['nombre_columna', 'tipo_dato', 'nullable', 'clave_primaria'],
        'modificar_tabla': ['nombre_columna', 'tipo_dato', 'accion'],
        'crear_usuarios': ['nombre_usuario', 'password', 'rol'],
        'asignar_permisos': ['usuario', 'tabla', 'permisos'],
    }
    
    columnas_requeridas = validaciones.get(tipo_solicitud, [])
    columnas_faltantes = [col for col in columnas_requeridas if col not in df.columns]
    
    if columnas_faltantes:
        return False, f"Faltan las siguientes columnas: {', '.join(columnas_faltantes)}"
    
    return True, "Estructura válida"

def generar_script_sql(solicitud):
    """
    Función principal para generar scripts SQL basados en el tipo de solicitud
    """
    if solicitud.tipo_solicitud in ['pull_request', 'despliegue']:
        # Para estos tipos, no se genera script automático
        return f"-- Solicitud de {solicitud.get_tipo_solicitud_display()}\n-- URL: {solicitud.url_commit}\n-- Branch: {solicitud.nombre_branch}\n-- Entorno: {solicitud.entorno}"
    
    if solicitud.archivo_adjunto and solicitud.tipo_archivo == 'excel':
        return procesar_archivo_excel(solicitud)
    
    return None
