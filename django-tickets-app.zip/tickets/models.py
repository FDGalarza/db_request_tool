from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserProfile(models.Model):
    ROLES = [
        ('dev', 'Ingeniero de Desarrollo'),
        ('db', 'Ingeniero de Bases de Datos'),
        ('devops', 'Ingeniero DevOps'),
        ('admin', 'Administrador'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLES, default='dev')
    
    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"

class Solicitud(models.Model):
    TIPOS_SOLICITUD = [
        ('crear_tabla', 'Creación de tablas base de datos'),
        ('modificar_tabla', 'Modificación de tabla base de datos'),
        ('compilar_objetos', 'Compilación de objetos'),
        ('asignar_permisos', 'Asignación de permisos'),
        ('crear_usuarios', 'Creación de usuarios y roles'),
        ('pull_request', 'Solicitud pull request'),
        ('despliegue', 'Solicitud de despliegue'),
    ]
    
    TIPOS_ARCHIVO = [
        ('excel', 'Excel'),
        ('zip', 'ZIP'),
        ('sql', 'SQL'),
    ]
    
    ESTADOS = [
        ('registrada', 'Registrada'),
        ('revision', 'En revisión'),
        ('aprobada', 'Aprobada'),
        ('rechazada', 'Rechazada'),
        ('finalizada', 'Finalizada'),
    ]
    
    tipo_solicitud = models.CharField(max_length=20, choices=TIPOS_SOLICITUD)
    tipo_archivo = models.CharField(max_length=10, choices=TIPOS_ARCHIVO, blank=True, null=True)
    archivo_adjunto = models.FileField(upload_to='solicitudes/', blank=True, null=True)
    estado = models.CharField(max_length=15, choices=ESTADOS, default='registrada')
    descripcion = models.TextField(blank=True, null=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    
    # Campos adicionales para Pull Request / Despliegue
    url_commit = models.URLField(blank=True, null=True)
    nombre_branch = models.CharField(max_length=100, blank=True, null=True)
    entorno = models.CharField(max_length=50, blank=True, null=True)
    
    # Script SQL generado
    script_sql_generado = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.get_tipo_solicitud_display()} - {self.usuario.username} - {self.estado}"
    
    class Meta:
        ordering = ['-fecha_creacion']

class HistorialEstado(models.Model):
    solicitud = models.ForeignKey(Solicitud, on_delete=models.CASCADE, related_name='historial')
    estado_anterior = models.CharField(max_length=15, choices=Solicitud.ESTADOS)
    estado_nuevo = models.CharField(max_length=15, choices=Solicitud.ESTADOS)
    usuario_cambio = models.ForeignKey(User, on_delete=models.CASCADE)
    fecha_cambio = models.DateTimeField(auto_now_add=True)
    comentario = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.solicitud.id} - {self.estado_anterior} -> {self.estado_nuevo}"

class Comentario(models.Model):
    solicitud = models.ForeignKey(Solicitud, on_delete=models.CASCADE, related_name='comentarios')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    texto = models.TextField()
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Comentario de {self.usuario.username} en solicitud {self.solicitud.id}"
    
    class Meta:
        ordering = ['-fecha_creacion']
