from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Solicitud, UserProfile, HistorialEstado, Comentario
from .forms import CustomUserCreationForm, SolicitudForm, ComentarioForm, CambiarEstadoForm
from .utils import procesar_archivo_excel, generar_script_sql
import json

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Cuenta creada exitosamente.')
            return redirect('dashboard')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def dashboard(request):
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]
    
    # Filtros
    tipo_solicitud = request.GET.get('tipo_solicitud', '')
    estado = request.GET.get('estado', '')
    fecha_desde = request.GET.get('fecha_desde', '')
    fecha_hasta = request.GET.get('fecha_hasta', '')
    
    # Base queryset según el rol
    if user_profile.role == 'admin':
        solicitudes = Solicitud.objects.all()
    else:
        solicitudes = Solicitud.objects.filter(usuario=request.user)
    
    # Aplicar filtros
    if tipo_solicitud:
        solicitudes = solicitudes.filter(tipo_solicitud=tipo_solicitud)
    if estado:
        solicitudes = solicitudes.filter(estado=estado)
    if fecha_desde:
        solicitudes = solicitudes.filter(fecha_creacion__date__gte=fecha_desde)
    if fecha_hasta:
        solicitudes = solicitudes.filter(fecha_creacion__date__lte=fecha_hasta)
    
    # Paginación
    paginator = Paginator(solicitudes, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'user_profile': user_profile,
        'tipos_solicitud': Solicitud.TIPOS_SOLICITUD,
        'estados': Solicitud.ESTADOS,
        'filtros': {
            'tipo_solicitud': tipo_solicitud,
            'estado': estado,
            'fecha_desde': fecha_desde,
            'fecha_hasta': fecha_hasta,
        }
    }
    return render(request, 'tickets/dashboard.html', context)

@login_required
def crear_solicitud(request):
    if request.method == 'POST':
        form = SolicitudForm(request.POST, request.FILES)
        if form.is_valid():
            solicitud = form.save(commit=False)
            solicitud.usuario = request.user
            solicitud.save()
            
            # Procesar archivo si es Excel
            if solicitud.archivo_adjunto and solicitud.tipo_archivo == 'excel':
                try:
                    script_sql = procesar_archivo_excel(solicitud)
                    if script_sql:
                        solicitud.script_sql_generado = script_sql
                        solicitud.save()
                        messages.success(request, 'Solicitud creada y script SQL generado exitosamente.')
                    else:
                        messages.warning(request, 'Solicitud creada, pero no se pudo generar el script SQL.')
                except Exception as e:
                    messages.error(request, f'Error al procesar el archivo: {str(e)}')
            else:
                messages.success(request, 'Solicitud creada exitosamente.')
            
            return redirect('detalle_solicitud', pk=solicitud.pk)
    else:
        form = SolicitudForm()
    
    return render(request, 'tickets/crear_solicitud.html', {'form': form})

@login_required
def detalle_solicitud(request, pk):
    solicitud = get_object_or_404(Solicitud, pk=pk)
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]
    
    # Verificar permisos
    if user_profile.role != 'admin' and solicitud.usuario != request.user:
        messages.error(request, 'No tienes permisos para ver esta solicitud.')
        return redirect('dashboard')
    
    # Formularios
    comentario_form = ComentarioForm()
    cambiar_estado_form = CambiarEstadoForm()
    
    # Procesar comentario
    if request.method == 'POST' and 'agregar_comentario' in request.POST:
        comentario_form = ComentarioForm(request.POST)
        if comentario_form.is_valid():
            comentario = comentario_form.save(commit=False)
            comentario.solicitud = solicitud
            comentario.usuario = request.user
            comentario.save()
            messages.success(request, 'Comentario agregado.')
            return redirect('detalle_solicitud', pk=pk)
    
    # Procesar cambio de estado (solo admin)
    if request.method == 'POST' and 'cambiar_estado' in request.POST and user_profile.role == 'admin':
        cambiar_estado_form = CambiarEstadoForm(request.POST)
        if cambiar_estado_form.is_valid():
            nuevo_estado = cambiar_estado_form.cleaned_data['nuevo_estado']
            comentario_texto = cambiar_estado_form.cleaned_data['comentario']
            
            # Crear historial
            HistorialEstado.objects.create(
                solicitud=solicitud,
                estado_anterior=solicitud.estado,
                estado_nuevo=nuevo_estado,
                usuario_cambio=request.user,
                comentario=comentario_texto
            )
            
            solicitud.estado = nuevo_estado
            solicitud.save()
            
            messages.success(request, f'Estado cambiado a {solicitud.get_estado_display()}.')
            return redirect('detalle_solicitud', pk=pk)
    
    context = {
        'solicitud': solicitud,
        'user_profile': user_profile,
        'comentario_form': comentario_form,
        'cambiar_estado_form': cambiar_estado_form,
        'puede_cambiar_estado': user_profile.role == 'admin',
    }
    return render(request, 'tickets/detalle_solicitud.html', context)

@login_required
def descargar_script_sql(request, pk):
    solicitud = get_object_or_404(Solicitud, pk=pk)
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]
    
    # Verificar permisos
    if user_profile.role != 'admin' and solicitud.usuario != request.user:
        messages.error(request, 'No tienes permisos para descargar este archivo.')
        return redirect('dashboard')
    
    if not solicitud.script_sql_generado:
        messages.error(request, 'No hay script SQL generado para esta solicitud.')
        return redirect('detalle_solicitud', pk=pk)
    
    response = HttpResponse(solicitud.script_sql_generado, content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename="script_solicitud_{pk}.sql"'
    return response

@login_required
def estadisticas(request):
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]
    
    if user_profile.role != 'admin':
        messages.error(request, 'No tienes permisos para ver las estadísticas.')
        return redirect('dashboard')
    
    # Estadísticas básicas
    total_solicitudes = Solicitud.objects.count()
    solicitudes_por_estado = {}
    for estado_code, estado_name in Solicitud.ESTADOS:
        count = Solicitud.objects.filter(estado=estado_code).count()
        solicitudes_por_estado[estado_name] = count
    
    solicitudes_por_tipo = {}
    for tipo_code, tipo_name in Solicitud.TIPOS_SOLICITUD:
        count = Solicitud.objects.filter(tipo_solicitud=tipo_code).count()
        solicitudes_por_tipo[tipo_name] = count
    
    context = {
        'total_solicitudes': total_solicitudes,
        'solicitudes_por_estado': solicitudes_por_estado,
        'solicitudes_por_tipo': solicitudes_por_tipo,
    }
    return render(request, 'tickets/estadisticas.html', context)
